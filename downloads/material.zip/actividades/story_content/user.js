function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6OA3TDW6n6b":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

